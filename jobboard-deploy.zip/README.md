# Job Board - Django Project

A modern job board application built with Django that allows companies to post job opportunities and users to browse and apply for positions.

## Features

- **User Roles**: Three distinct user roles (Admin, Company, User)
- **Job Management**: Companies can create, edit, and delete their job postings
- **Search Functionality**: Search jobs by title or location
- **Responsive Design**: Modern UI with Bootstrap 5
- **Admin Interface**: Full Django admin integration for platform management

## User Roles

### Admin
- Manage the platform via Django admin interface
- Can view and manage all users and job postings

### Company
- Create, edit, and delete their own job postings
- Access to job management features

### User
- Browse and search available jobs
- View detailed job information
- Apply via external application links

## Technology Stack

- **Backend**: Django 5.2.5
- **Database**: SQLite (development)
- **Frontend**: Bootstrap 5.3.0
- **Icons**: Font Awesome 6.0.0

## Installation & Setup

### Prerequisites
- Python 3.8 or higher
- pip (Python package installer)

### Step 1: Clone or Download the Project
```bash
# If you have this project in a repository
git clone <repository-url>
cd jobboard

# Or navigate to your project directory
cd /path/to/your/project
```

### Step 2: Create Virtual Environment
```bash
python3 -m venv venv
```

### Step 3: Activate Virtual Environment
```bash
# On macOS/Linux
source venv/bin/activate

# On Windows
venv\Scripts\activate
```

### Step 4: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 5: Run Database Migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### Step 6: Create Superuser (Admin)
```bash
python manage.py createsuperuser
```

### Step 7: Run the Development Server
```bash
python manage.py runserver
```

The application will be available at `http://127.0.0.1:8000/`

## Usage

### Initial Setup
1. Access the admin interface at `http://127.0.0.1:8000/admin/`
2. Log in with your superuser credentials
3. Create user accounts for companies and regular users
4. Set appropriate roles for each user:
   - Go to Users → select a user → Profile → set role

### For Companies
1. Log in with a company account
2. Click "Add Job" in the navigation
3. Fill out the job posting form
4. Manage your job postings from the job detail pages

### For Users
1. Browse available jobs on the homepage
2. Use the search functionality to find specific positions
3. Click "View Details" to see full job information
4. Click "Apply Now" to be redirected to the company's application page

## Project Structure

```
jobboard/
├── jobboard/          # Main project settings
├── jobs/             # Main application
│   ├── models.py     # Database models
│   ├── views.py      # View functions
│   ├── forms.py      # Form classes
│   ├── urls.py       # URL patterns
│   └── admin.py      # Admin interface
├── templates/        # HTML templates
│   ├── base.html     # Base template
│   ├── jobs/         # Job-related templates
│   └── registration/ # Authentication templates
├── static/           # Static files (CSS, JS)
├── manage.py         # Django management script
├── requirements.txt  # Python dependencies
└── README.md        # This file
```

## URL Structure

- `/` - Job listing page (homepage)
- `/jobs/<id>/` - Individual job details
- `/jobs/add/` - Add new job (companies only)
- `/jobs/<id>/edit/` - Edit job (owner only)
- `/jobs/<id>/delete/` - Delete job (owner only)
- `/login/` - User login
- `/logout/` - User logout
- `/admin/` - Django admin interface

## Customization

### Adding New Fields
To add new fields to the Job model:
1. Modify `jobs/models.py`
2. Run `python manage.py makemigrations`
3. Run `python manage.py migrate`
4. Update forms and templates as needed

### Styling
The application uses Bootstrap 5. You can customize the appearance by:
1. Modifying the base template (`templates/base.html`)
2. Adding custom CSS in the `static/css/` directory
3. Overriding Bootstrap classes in individual templates

## Security Features

- CSRF protection on all forms
- User authentication and authorization
- Role-based access control
- Input validation and sanitization
- Secure password handling

## Development

### Running Tests
```bash
python manage.py test
```

### Creating New Migrations
```bash
python manage.py makemigrations jobs
```

### Applying Migrations
```bash
python manage.py migrate
```

## Deployment

For production deployment:
1. Set `DEBUG = False` in settings.py
2. Configure a production database (PostgreSQL recommended)
3. Set up static file serving
4. Configure environment variables for sensitive data
5. Use a production WSGI server (Gunicorn, uWSGI)

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is open source and available under the MIT License.

## Support

For questions or issues, please create an issue in the project repository or contact the development team.
